delete from a_users where nationId = 'UKR';

insert into a_users(userId, nationId, userName, roleId, orgId, pswd) values
('u01', 'UKR', 'M142 HIMARS', 'artillary', 'ukr-artillary', 'слава'),
('u02', 'UKR', 'M777', 'artillary', 'ukr-artillary', 'слава'),
('u03', 'UKR', 'CAESAR Self-propelled', 'artillary', 'ukr-artillary', 'слава'),
('u04', 'UKR', 'PzH2000 Self-propelled', 'artillary', 'ukr-artillary', 'слава'),
('u05', 'UKR', 'DANA 152mm Wheeled', 'artillary', 'ukr-artillary', 'слава'),
('u06', 'UKR', 'FH70 155mm Toweed', 'artillary', 'ukr-artillary', 'слава'),
('u07', 'UKR', 'Krab 155mm Tracked Self-propelled', 'artillary', 'ukr-artillary', 'слава'),
('u08', 'UKR', 'M270 MRLS', 'artillary', 'ukr-artillary', 'слава'),
('u09', 'UKR', 'AN/TPQ-36 counter-artillery radar', 'artillary', 'ukr-artillary', 'слава'),
('u11', 'UKR', 'NLAW', 'anti-armor', 'ukr-army', 'слава'),
('u12', 'UKR', 'Javelin', 'anti-armor', 'ukr-army', 'слава'),
('u13', 'UKR', 'GT4', 'anti-armor', 'ukr-army', 'слава'),
('u14', 'UKR', 'Harpoon', 'anti-ship', 'ukr-army', 'слава'),
('u15', 'UKR', 'Neptune', 'anti-ship', 'ukr-army', 'слава'),
('u21', 'UKR', 'Stinger', 'anti-air', 'ukr-army', 'слава'),
('u22', 'UKR', 'Starstreak', 'anti-air', 'ukr-army', 'слава'),
('u23', 'UKR', 'Iron Dome', 'anti-air', 'ukr-army', 'слава'),
('u31', 'UKR', 'Bayraktar TB2', 'drone', 'ukr-drone', 'слава'),
('u32', 'UKR', 'Switchblade Tactical Unmanned Aerial Systems', 'drone', 'ukr-drone', 'слава'),
('u33', 'UKR', 'Malloy T150 Heavy Lift', 'drone', 'ukr-drone', 'слава') ;
