package io.odysz.jsample.servs;

import io.odysz.semantic.jserv.user.UserReq;

public class SampleReq extends UserReq {

}
