package io.odysz.jsample.utils;

public class StrRes {

	public static final String quizId_cant_null =  "Quiz Id can not be null!";
	public static final String some_polls_already_done = "Some polls already finished. Quiz can not be updated.";
	public static final String zero_questions_illegal_quiz = "None questions for the quiz. Quiz updating is invalid.";

	public static final String insert_null_record = "Failed on inserting null record.";
	public static final String logid_exits = "Log ID already exits";
}
