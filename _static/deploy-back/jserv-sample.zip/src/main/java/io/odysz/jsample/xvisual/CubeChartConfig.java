package io.odysz.jsample.xvisual;

import io.odysz.anson.Anson;

public class CubeChartConfig extends Anson{
	String[] valueRange;
	String[] legend;
}
