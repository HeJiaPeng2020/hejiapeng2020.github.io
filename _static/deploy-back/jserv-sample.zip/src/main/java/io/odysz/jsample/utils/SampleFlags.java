package io.odysz.jsample.utils;

public class SampleFlags {

	public static final boolean echo = true;
	public static final boolean menu = true;
	public static final boolean cheapflow = true;

	public static final boolean user = true;
	public static final boolean xvisual = true;
}
